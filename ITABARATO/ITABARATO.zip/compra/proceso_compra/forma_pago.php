<?php 
session_start();
$_SESSION["pago"]=$_POST["pago"];
?>