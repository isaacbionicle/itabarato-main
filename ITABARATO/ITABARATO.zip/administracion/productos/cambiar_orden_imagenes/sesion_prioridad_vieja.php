<?php 

session_start();

$_SESSION["prioridad_vieja"]=$_POST["prioridad_vieja"];
$_SESSION["id"]=$_POST["id"];

?>